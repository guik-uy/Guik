# Guik — cómo instalarla en tu iPhone (sin Mac)

Guik es una **PWA**: una web app que se instala como ícono en tu iPhone, funciona
offline y guarda los datos en el teléfono. No necesitás Mac, ni App Store, ni
cuenta Apple, ni pagar nada.

Para instalarla necesitás un link **https** (no sirve abrir el archivo suelto).
Subir la carpeta a un hosting gratis lleva 2 minutos. Elegí UNA opción:

---

## Opción A — Netlify Drop (recomendada, sin cuenta para probar)

1. En tu PC, andá a **https://app.netlify.com/drop**
2. Arrastrá la **carpeta** `Guik` (entera) a la zona que dice "drag and drop".
3. Te da un link tipo `https://algo-random.netlify.app` → ese es tu Guik online.
4. En el **iPhone**, abrí ese link en **Safari**.
5. Tocá el botón **Compartir** (cuadrado con flecha) → **Añadir a inicio**.
6. Listo: ícono de Guik en tu pantalla. Se abre a pantalla completa, como app.

> Para que el link no expire, Netlify te pedirá crear cuenta gratis (Google, 10 seg).

## Opción B — tiiny.host (subís el .zip)

1. Andá a **https://tiiny.host**
2. Subí el archivo **`Guik.zip`** (está en el Escritorio, al lado de la carpeta).
3. Te da un link https → abrilo en Safari (iPhone) → Compartir → Añadir a inicio.

## Opción C — GitHub Pages (gratis para siempre, si tenés GitHub)

1. Creá un repo público, subí el contenido de la carpeta `Guik`.
2. Settings → Pages → Branch `main` / root → Save.
3. Te da `https://tuusuario.github.io/repo/` → abrir en Safari → Añadir a inicio.

---

## Importante — no pierdas tus datos

Los datos viven **solo en tu iPhone** (no hay nube). iOS puede borrar el
almacenamiento de una web si te quedás sin espacio o no la abrís por semanas.

**Por eso:** cada tanto entrá a **Ajustes (engranaje arriba a la derecha) →
Exportar datos**. Te baja un archivo `.json` de respaldo. Si pasa algo, lo
recuperás con **Importar datos**.

La primera vez la app trae datos de ejemplo (6 semanas). Cuando quieras empezar
limpio: **Ajustes → Borrar todos los datos**.

---

## Probarla ya en la PC (opcional)

Doble clic en `index.html` la abre en tu navegador para mirarla. Para que guarde
bien y se instale en el iPhone, igual hay que subirla con una de las opciones de
arriba.
